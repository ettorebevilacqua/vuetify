<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/

require("classes/buonoTable.php");


class buonocreabuonoModuleFrontController extends ModuleFrontController
{

  public function initContent()
  {
    parent::initContent();
    $amount=Tools::getValue('amount');
    if(empty($amount)) exit;
    require('classes/storiaBuonoTable.php');
    $b=new StoriaBuonoTable(_DB_PREFIX_."storia_buono");
    date_default_timezone_set('UTC');
    $date = date('Y-m-d H:i:s');
    $id_customer=(int)$this->context->cookie->id_customer;
    $b->newRow($amount,$id_customer,$date);
    $values=$this->createCoupon($amount,$this->context->customer->id,$this->context->cookie->id_lang);
    $this->eliminaProvvigioneById((int)$this->context->cookie->id_customer);
    $this->context->smarty->assign(array(
    'amount'=>$values['riduzione'],'code'=>$values['code'],
    'description'=>$values['description'],'minimo'=>$values['minimo'],
    'scadenza'=>$values['scadenza']));
    $this->setTemplate('creabuono.tpl');
  }


  /**
   * Elimina provvigione dalla tabella acquisti_inviti
   * @param  [int] $id_padre [id del padre ,cioè di chi ha guadagnato]
   * @return [null]           [/]
   */
  private function eliminaProvvigioneById($id_padre)
  {
    $sql = 'DELETE FROM '._DB_PREFIX_.'acquisti_inviti WHERE id_padre='.$id_padre;
    $results = Db::getInstance()->query($sql);
  }


  /**
   * Crea il Coupon e lo aggiunte automaticamente al sistema di prestashop
   * @param  [float] $amount      [description]
   * @param  [type] $id_customer [description]
   * @param  [type] $id_lang     [description]
   * @return [type]              [description]
   */
  private function createCoupon($amount,$id_customer,$id_lang)
  {
   $coupon = new Discount();
   $coupon->quantity = 1;
   $coupon->quantity_per_user = 1;
   $coupon->id_discount_type = 2;
   $coupon->value=$amount;
   $date=$this->getDate();
   $coupon->date_from = $date['start'];
   $coupon->date_to = $date["end"];
   $coupon->code=Tools::passwdGen(8);
   $coupon->name =$this->getNameLang();
   $current_language = (int)$id_lang;
   $coupon->id_customer = $id_customer;
	 $coupon->reduction_currency = 1;
	 $coupon->minimum_amount = $this->getPrezzoMinimo();
	 $coupon->code = Tools::passwdGen(5);
	 //$coupon->minimal = $coupon->value;
		  $coupon->active = 1;
    $coupon->cart_display = 1;
    $coupon->cart_rule_restriction = 0;
    $coupon->description = "provvigione guadagnata";
    $coupon->highlight = 1;
		 $coupon->add();
     $array=array("code"=>$coupon->code,"description"=>$coupon->description,
             "minimo"=>$coupon->minimum_amount,"riduzione"=>$coupon->reduction_amount,
             "scadenza"=>$date['end']);
     return $array;
  }


/**
 * Crea il nome del buono
 * @return [Array of String] [Formato standard prestashop]
 */
private function getNameLang()
{
  $languages = Language::getLanguages(true,false);
  $namelang = array();
  foreach ($languages as $language) $namelang[$language['id_lang']] = "provvigione";
  return $namelang;
}


/**
 * Per ottenre la data d'inizio del buono e la sua scadenza
 * @return [Array of String] ["start" data d'inizio, "end" data scadenza]
 */
private function getDate()
{
  $start = date('Y-m-d H:i:s');
  $t=new buonoTable(_DB_PREFIX_."buono");
  $plus=$t->getData();
  date_default_timezone_set('UTC');
  $date = strtotime("+".$plus." day");
  $end= date('Y-m-d H:i:s', $date);
  $array=array("start"=>$start,"end"=>$end);
  return $array;
}


/**
 * Prezzo minimo di acuisto con buono sconto
 * @return [float] [prezzo minimo]
 */
private function getPrezzoMinimo()
{
  $t=new buonoTable(_DB_PREFIX_."buono");
  return $t->getMinimo();
}


}//..end
 ?>
