<?php


class StoriaBuonoTable extends TableAbstract
{


  /**
   * Crea tabella PS_buono
   * @return [null] [/]
   */
  public function createTable()
  {
    $sql='CREATE TABLE '.$this->name.' ( id int NOT NULL AUTO_INCREMENT, data datetime ,guadagno float,id_customer int ,primary key (id));';
    try {
              $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
         } catch (Exception $e)
         {   //ESISTE GIÀ LA TABELLA
         }
  }

  /**
   * Imposta il campo Data
   * @param [int] $n [Numero di giorni per la scadenza]
   */
  public function newRow($amount,$id_customer,$data)
  {
    $sql="INSERT INTO $this->name  (data,guadagno,id_customer) VALUES($data,$amount,$id_customer)";
    try {
              $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
         } catch (Exception $e)
         {
         }
  }

}//end..
 ?>
