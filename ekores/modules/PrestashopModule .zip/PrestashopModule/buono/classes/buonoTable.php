<?php
require('TableAbstract.php');

class BuonoTable extends TableAbstract
{
  /**
   * Crea tabella PS_buono
   * @return [null] [/]
   */
  public function createTable()
  {
    $sql='CREATE TABLE '.$this->name.' ( id int NOT NULL AUTO_INCREMENT, data int ,minimo float ,primary key (id));';
    try {
              $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
         } catch (Exception $e)
         {   //ESISTE GIÀ LA TABELLA
         }
  }

  /**
   * Imposta il campo Data
   * @param [int] $n [Numero di giorni per la scadenza]
   */
  public function setData($n)
  {
    $sql="UPDATE $this->name  SET data=".$n." WHERE id=1";
    try {
              $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
         } catch (Exception $e)
         {   //ESISTE GIÀ LA TABELLA
         }
  }
  /**
   * Ritorna i giorni dalla scadenza
   * @return [int] [numero di giorni che mancano alla scadenza]
   */
  public function getData()
  {
    $sql="SELECT data FROM $this->name WHERE id=1";
    $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
    while ($row=Db::getInstance()->nextRow($results))  {
      if($row)
          return $row['data'];
                                                        }
    return null;
  }

  /**
   * Salva sul DB il prezzo minimo per acquisto con il buono
   * @param [float] $f [prezzo minimo buono sconto]
   */
  public function setMinimo($f)
  {
    $sql="UPDATE $this->name  SET minimo=".$f." WHERE id=1";
    try {
    $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        }
        catch (Exception $e)
        {   //ESISTE GIÀ LA TABELLA
        }
  }

  /**
   * Per ottenere il  prezzo minimo del buono sconto impostato sul DB
   * @return [float] [prezzo minimo buono sconto]
   */
  public function getMinimo()
  {
    $sql="SELECT minimo FROM $this->name WHERE id=1";
    $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
    while ($row=Db::getInstance()->nextRow($results))
    {
      if($row)
      return $row['minimo'];
    }
    return null;
  }


  /**
   * Crea la prima riga sulla tabella Buono
   * con valori nulli o vuoti
   * @return [type] [description]
   */
  public function inizializza()
  {
    $sql="INSERT INTO $this->name (data,minimo) VALUES (0,0.00)";
    try {
    $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        }
        catch (Exception $e)
        {   //ESISTE GIÀ LA TABELLA
        }
  }

}//..end


 ?>
