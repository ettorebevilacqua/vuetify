<?php

abstract class TableAbstract{

    /**
     * Nome tabella
     * @var [String]
     */
    var $name;


    public function __construct($n)
    {
      $this->name=$n;
    }


    /**
     * Verifica se esiste la tabella 'PS_$name'
     * @return [Boolean] [True se esiste, False se non esiste]
     */
        public function checkExist()
     {
       $exist=False;
       $sql='SHOW TABLES LIKE \''.$this->name.'\'';
       $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
          while ($row=Db::getInstance()->nextRow($results))  {
           if($row) $exist=True;
                                                             }
          return $exist;
     }

     /**
      * Elimina la tabella dal DB
      * @return [null]
      */
     public function dropTable()
     {
       $sql='DROP TABLE '.$this->name;
       try {
               $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
           } catch (Exception $e)
           {
           //NON ESISTE LA TABELLA
           }
     }

}//..end


 ?>
