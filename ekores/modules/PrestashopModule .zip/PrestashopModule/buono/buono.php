<?php
if(!defined('_PS_VERSION_'))
  exit;

  /*ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);*/

class Buono extends Module
{

  public function __construct()
  {
    $this->name = 'buono';
    $this->tab = 'others';
    $this->version = '1.0';
    $this->author = 'Riccardo Amadio';

    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.5', 'max' => '1.6');
    $this->dependencies = array('blockcart');

    parent::__construct();

    $this->displayName = $this->l('Buono Sconto');
    $this->description = $this->l('Buono Sconto');
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

    if (!Configuration::get('MYMODULE_NAME'))
      $this->warning = $this->l('No name provided');
  }


  public function install()
  {
  if (Shop::isFeatureActive())
      Shop::setContext(Shop::CONTEXT_ALL);

      require('classes/buonoTable.php');
      $t=new BuonoTable(_DB_PREFIX_."buono");
      if($t->checkExist())
            $t->dropTable();
      $t->createTable();
      $t->inizializza();

      require('classes/storiaBuonoTable.php');
      $b=new StoriaBuonoTable(_DB_PREFIX_."storia_buono");
      $b->createTable();

      return parent::install() &&
        $this->registerHook('leftColumn') &&
        $this->registerHook('header') &&
        Configuration::updateValue('MYMODULE_NAME', 'my friend');
  }



      public function uninstall()
      {
      if (!parent::uninstall() ||
        !Configuration::deleteByName('MYMODULE_NAME'))
        return false;
      return true;
      }


    /*CONTROLLER  PAGINA CONFIGURAZIONE MODULO*/
    public function getContent()
    {
      $output = null;

    if (Tools::isSubmit('submit'.$this->name))
    {
        $giorni = strval(Tools::getValue('giorni'));
        $prezzo = strval(Tools::getValue('prezzo'));

        if (!$giorni
          || empty($giorni)
          || !Validate::isGenericName($giorni)
          || !$prezzo
          || empty($prezzo)
          || !Validate::isGenericName($prezzo))
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {
            Configuration::updateValue('giorni', $giorni);
            Configuration::updateValue('prezzo', $prezzo);
            $this->updateBuonoTable($prezzo,$giorni);
            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }
    }
    return $output.$this->displayForm();
    }


    public function displayForm()
{
    // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('Impostazione Buono Sconto'),
        ),
        'input' => array(
            array(
                'type' => 'text',
                'label' => $this->l('Numero di giorni dalla scadenza'),
                'name' => 'giorni',
                'size' => 20,
                'required' => true
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Prezzo minimo'),
                'name' => 'prezzo',
                'size' => 20,
                'required' => true
            )
        ),
        'submit' => array(
            'title' => $this->l('Save'),
            'class' => 'button'
        )
    );
    //Create helper
    $helper=$this->createHelper($default_lang);

    // Load current value
    $helper->fields_value['giorni'] = Configuration::get('giorni');
    $helper->fields_value['prezzo'] = Configuration::get('prezzo');
    return $helper->generateForm($fields_form);
}



/**
 * Aggiorna il database sulla configurazione del Buono Sconto
 * @param  [float] $prezzo [prezzo minimo per usare il buono]
 * @param  [int] $data   [numero di giorni che si ha per usare il buono]
 * @return [null]         [/]
 */
private function updateBuonoTable($prezzo,$data)
{
  require('classes/buonoTable.php');
  $t=new BuonoTable(_DB_PREFIX_."buono");
  $t->setData($data);
  $t->setMinimo($prezzo);
}


/**
 * Crea l'oggeto helper che si occupa del templating
 * @param  [int] $default_lang [varibile di sistema che indica la lingua attuale del negozio]
 * @return [Object]               [PrestashopObject per il templating]
 */
private function createHelper($default_lang)
{
  $helper = new HelperForm();

  // Module, token and currentIndex
  $helper->module = $this;
  $helper->name_controller = $this->name;
  $helper->token = Tools::getAdminTokenLite('AdminModules');
  $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

  // Language
  $helper->default_form_language = $default_lang;
  $helper->allow_employee_form_lang = $default_lang;

  // Title and toolbar
  $helper->title = $this->displayName;
  $helper->show_toolbar = true;        // false -> remove toolbar
  $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
  $helper->submit_action = 'submit'.$this->name;
  $helper->toolbar_btn = array(
      'save' =>
      array(
          'desc' => $this->l('Save'),
          'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
          '&token='.Tools::getAdminTokenLite('AdminModules'),
      ),
      'back' => array(
          'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
          'desc' => $this->l('Back to list')
      )
  );

  return $helper;
}






}//end..

 ?>
