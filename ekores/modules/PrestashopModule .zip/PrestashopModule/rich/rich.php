<?php
if (!defined('_PS_VERSION_'))
  exit;

  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

class rich extends PaymentModule
{
  /**
   * Nome tabella
   * @var [string]
   */
  private  $name_table;

  public function __construct()
    {
      $this->name = 'rich';
      $this->tab = 'payments_gateways';
      $this->version = '1.0.0';
      $this->author = 'Riccardo Amadio';
      $this->controllers = array('payment', 'validation');
      $this->ps_versions_compliancy['min'] = '1.6.0';
      $this->is_eu_compatible = 1;

      $this->currencies = true;
      $this->currencies_mode = 'checkbox';


      $this->bootstrap = true;
        parent::__construct();

    $this->displayName = $this->l('Rich Pay');
		$this->description = $this->l('Rich Pay');
    $this->name_table=_DB_PREFIX_.'acquisti_inviti';//NOME TABELLA

    }


    public function install()
	{
      require("utils/table.php");
      $table=new Table($this->name_table);
      if($table->checkIfExistTable())
          $table->dropTable();
      $table->createTable();

    return parent::install()
  			&& $this->registerHook('displayPayment')
        && $this->registerHook('displayPaymentReturn');
  }



  public function uninstall()
    {   require("utils/table.php");
        $table=new Table($this->name_table);
        $table->dropTable();

        return parent::uninstall();
    }

    //Pagina Configurazione modulo
    public function getContent()
    {
      require("utils/layout.php");
      $layout=new Layout();

      $results=Db::getInstance()->query("SELECT * FROM ".$this->name_table);
      if(!empty($results))
      {
        $tableGuadagni=$layout->createTableGuadagni($results);

          return  $layout->createTableTrasferimenti().
          "</br></br></br></br>".
          $tableGuadagni.
          "</br></br></br></br>".
          $layout->createTableClientiFigli();

}
      else
          return "<h1>NON CI SONO DATI</h1>";
    }





    public function hookdisplayPayment($params)
   {
       if (!$this->active) {
           return;
       }
       if (!$this->checkCurrency($params['cart'])) {
           return;
       }
       $this->smarty->assign(array(
           'this_path' => $this->_path,
           'this_path_bw' => $this->_path,
           'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
       ));
       return $this->display(__FILE__, 'payment.tpl');
   }




    public function hookdisplayPaymentReturn($params)
    {    return '<div class="box">SUCCESS</div>';   }


    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

}//..end

 ?>
