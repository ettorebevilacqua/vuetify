<?php

class Layout {


public function __construct(){}



public function createTableTrasferimenti()
{
  require('storiaBuonoTable.php');
  $s=new StoriaBuonoTable(_DB_PREFIX_."storia_buono");
  $data=$s->getData();
  if($data==null) return "<h1> NON CI SONO TRASFERIMENTI</h1>";
  $html=$this->createHeadTable("trasferimento");
  foreach($data as $elem)
  {
    $html=$html."<tr>";
    $i=0;
    for($i=0;$i<count($elem)/2;$i++)
    {
      $field=$elem[$i];
      if(((count($elem)/2)-1)==$i)
        {
          $html=$html."<td>$field</td><td>".$this->getNomeCognomeById($field)."</td>";
        }
        else
        {
          $html=$html."<td>$field</td>";
        }

    }
    $html=$html."</tr>";

  }
  return $html."</table>";
}


/**
 * Crea HTML tabella guadagni per ogni acquisto fatto da clienti invitati
 * @param  [Array] $results [Struttura PS_acquisti_inviti]
 * @return [String]          [HTML tabella]
 */
public function createTableGuadagni($results)
{
  $html=$this->createHeadTable("guadagni");

  foreach($results as $elem)
  {

    $html.="<tr>";

    for($i=0;$i<count($elem)/2;$i++)
    {
      if($i==7 || $i==8)
          $html.="<td>".number_format(floatval($elem[$i]), 2,',',' ')."</td>";
      else
          $html.="<td>".$elem[$i]."</td>";
    }
    $html.="</tr>";
  }
  return $html."</table>";
}



/**
 * Crea HTML tabella clienti con Invito
 * @return [String] [HTML tabella]
 */
public function createTableClientiFigli()
{
  $results=Db::getInstance()->query("SELECT * FROM "._DB_PREFIX_."customer ");
  $table=$this->createHeadTable("clienti");
       while ($row=Db::getInstance()->nextRow($results))
       {
        if($row)
        {
          $id_padre=$this->calcolaIdByPromotioncode($row['promotion_code']);

          $table.="<tr><td>".$row['id_customer']."</td>";
          $table.="<td>".$row['firstname']." ".$row['lastname']."</td>";
          $table.= ($id_padre==null) ? "<td> </td>" : "<td>".$id_padre."</td>";
          $table.= ($id_padre==null) ? "<td> </td>" : "<td>".$this->getNomeCognomeById($id_padre)."</td>";
          $table.="<td>".$row['date_add']."</td></tr>";
        }
       }
        $table.="</table>";
        return $table;
 }



/**
 * Crea l'HEAD della tabella Guadagni o Inviti
 * @param  [String] $key ["guadagni" o "clienti"]
 * @return [String]      [HTML Head]
 */
private function createHeadTable($key)
{
  if($key=="guadagni")
  {
    return "<h1>PROVVIGIONE CLIENTI</h1></br></br>
    <table class='table table-bordered table-responsive'><tr>
    <th>ID</th><th>ID PADRE</th><th>NOME PADRE</th>
    <th>ID FIGLIO</th><th>NOME FIGLIO</th>
    <th>ID PRODOTTO</th><th>NOME PRODOTTO</th>
    <th>PREZZO TOTALE</th><th>PROVVIGIONE</th></tr>";
  }
  if($key=="clienti")
  {
    return "<h1>CLIENTI E INVITATI</h1></br></br>
    <table class='table table-bordered table-responsive'><tr>
    <th>ID</th><th>NOME COGNOME</th><th>ID PADRE</th>
    <th>NOME PADRE</th><th>DATA ISCRIZIONE</th></tr>";
  }
  if($key=="trasferimento")
  {
    return "<h1>PROVVIGIONI TRASFERITE</h1></br></br>
    <table class='table table-bordered table-responsive'><tr>
    <th>ID</th><th>DATA</th><th>PROVVIGIONE</th><th>ID CUSTOMER</th>
    <th>NOME COGNOME</th></tr>";
  }

}



/**
 * Dato un codice invito restituisce l'id decriptato contenuto nel codice invito
 * @param  [String] $promotion_code [Codice Invito]
 * @return [Int]                 [Id]
 */
private function calcolaIdByPromotioncode($promotion_code)
{
  $id=null;
  $cont=0;
  for($i=0;$i<strlen($promotion_code);$i++)
  {
    if(ctype_alpha($promotion_code[$i]))
          $cont++;
    else
    {
          if($cont==1)    $id=$id.$promotion_code[$i];
    }
  }
  return $id;
}


/**
 * Cerca il nome e cognome dell'id all'interno della tabella ps_customer
 * @param  [Int] $id [Id cliente]
 * @return [String]     [Nome Cognome]
 */
private function getNomeCognomeById($id)
{
$sql="SELECT firstname,lastname FROM "._DB_PREFIX_."customer WHERE id_customer=".$id;
$results=Db::getInstance()->query($sql);
while ($row=Db::getInstance()->nextRow($results))
  {
 if($row)
   return $row['firstname']." ".$row['lastname'];
  }
return null;
}


}//..end
 ?>
