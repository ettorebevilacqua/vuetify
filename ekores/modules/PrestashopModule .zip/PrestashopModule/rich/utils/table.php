<?php

class Table{

/**
 * Nome tabella
 * @var [String]
 */
private $name;


public function __construct($n)
{
  $this->name=$n;
}

/**
 * Controlla se esiste la tabella $this->name
 * @return [Boolean] [TRUE se esiste,FALSE altrimenti]
 */
public function checkIfExistTable()
{
  $exist=False;
  $sql='SHOW TABLES LIKE \''.$this->name.'\'';
  $results = Db::getInstance()->query($sql);
     while ($row=Db::getInstance()->nextRow($results))
       {
      if($row)
      return true;
       }
     return false;
}

/**
 * Elimina la tabella $this->name
 * @return [null] [/]
 */
public function dropTable()
{
  $sql='DROP TABLE '.$this->name;
  Db::getInstance()->query($sql);
}


/**
 * Crea la tabella $this->name
 * @return [null] [/]
 */
public function createTable()
{
  $sql = '
  CREATE TABLE  '.$this->name.'
(
id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
id_padre int,
nome_padre varchar(500),
id_figlio int,
nome_cognome varchar(500),
id_prodotto int,
nome_prodotto varchar(500),
total_price float,
provvigione float
);';
 Db::getInstance()->query($sql);
}

}//..end


 ?>
