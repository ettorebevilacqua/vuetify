<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class RichValidationModuleFrontController extends ModuleFrontController
{
    /**
    * @see FrontController::postProcess()
    */
    public function postProcess()
    {
        $cart = $this->context->cart;
        $status=2;

        //PRENDO PREZZO TOTALE
        session_start();
        if(!empty($_SESSION["amount"]))
        $amount=number_format($_SESSION["amount"], 2, ',', ' ');
        else
          exit;

          //CREO OGGETO CLIENTE
          include "classes/client.php";
          $id = (int)$this->context->cookie->id_customer;
          $c=new Client($id);

          //CALCOLA ID DEL RE
          $id_re=$c->calcolaRe();

          //ALGORITMO FIGLIO
          $id_customer=$id;
          $this->algortimoFiglio($c,$id_customer,$cart);


          //ALGORITMO RE
          $this->algortimoRe($id_re,$c,$cart);

          //CONCLUDI ACQUISTO
          $this->module->validateOrder((int)$cart->id, _PS_OS_PAYMENT_, $amount, $this->module->displayName,
           "Customer redirected", array('transaction_id' => $this->context->cookie->pcid), false, false,
            $this->context->customer->secure_key,$this->context->shop);
            $this->context->smarty->assign(array('response1'=>"<h1>SUCCESS!</h1>"));
            $this->setTemplate('validation.tpl');


    }


    /**
     * ESEGUE L'ALGORITMO FIGLIO
     * @param  [Oggetto Cliente] $c           [cliente]
     * @param  [int] $id_customer [description]
     * @param  [PrestashopObject] $cart        [Carrelo Oggetto Prestashop]
     * @return [null]              [nulla]
     */
    public function algortimoFiglio($c,$id_customer,$cart)
    {
        $id_padre=$c->calcolaIdPadre();
        $c->pagamento($cart,$id_customer,$id_padre);
    }


    /**
     * ESEGUE ALGORITMO RE
     * @param  [int] $id_re [id_customer del RE]
     * @param  [ClientObject] $c     [oggeto che rappresenta il cliente corrente]
     * @param  [PrestashopObject] $cart     [carrelo del cliente per Prestashop]
     * @return [null]        [null]
     */
    public function algortimoRe($id_re,$c,$cart)
    {
      $id_nonno=$this->algoritmoNonno($c,$cart);
      if($id_nonno==$id_re)
      {
        return null;
      }
      else
      {
        $id_padre=$c->calcolaIdPadre();
        $promotion_code_padre=$c->getPromotionCodeById($id_padre);
        $clienti=$c->getClientiOrdinatiDataPromotioncode($promotion_code_padre);
        $primi_due=array((array_key_exists(0,$clienti)?$clienti[0]:null),
        (array_key_exists(1,$clienti)?$clienti[1]:null));
        if(in_array($id_padre,$primi_due))
        {
          $id_customer=$c->id_customer;
          $promotion_code=$c->getPromotionCodeById($id_customer);
          $clienti_customer=$c->getClientiOrdinatiDataPromotioncode($promotion_code);
          $primi_due_customer=array((array_key_exists(0,$clienti_customer)?$clienti_customer[0]:null),
        (array_key_exists(1,$clienti_customer)?$clienti_customer[1]:null));
          if(in_array($id_customer,$primi_due_customer))
            {
              $c->pagamento($cart,$c->id_customer,$id_re);
              return null;
            }
            else
            {
              return null;
            }
        }
        else
        {
          return null;
        }
      }
    }

    /**
     * ESEGUE ALGORITMO NONNO
     * @param  [ClientiObject] $c    [oggeto che rappresenta il cliente corrente]
     * @param  [PrestashopObject] $cart [carrelo oggetto prestashop]
     * @return [int]       [id_nonno o null]
     */
    public function algoritmoNonno($c,$cart)
    {
      $id_padre=$c->calcolaIdPadre();
      $promotion_code_padre=$c->getPromotionCodeById($id_padre);
      $clienti=$c->getClientiOrdinatiDataPromotioncode($promotion_code_padre);
      $primi_due=array(((array_key_exists(0,$clienti)) ? $clienti[0] : null),
    ((array_key_exists(1,$clienti)) ? $clienti[1] : null));
      if(in_array($id_padre,$primi_due))
      {
          return $c->calcolaIdSuperiore($id_padre);
        }
      else
        {
            $id_customer=$c->id_customer;
            $promotion_code=$c->getPromotionCodeById($id_customer);
            $clienti_customer=$c->getClientiOrdinatiDataPromotioncode($promotion_code);
            $primi_due_customer=array(((array_key_exists(0,$clienti_customer)) ? $clienti_customer[0] : null),
          ((array_key_exists(1,$clienti_customer)) ? $clienti_customer[1] : null));
            if(!in_array($id_customer,$primi_due_customer))
            {
                return  $c->calcolaIdSuperiore($id_padre);
            }
                else
                {
                  $id_nonno=$c->calcolaIdSuperiore($id_padre);
                  $c->pagamento($cart,$c->id_customer,$id_nonno);
                  return $id_nonno;
                }
        }

      }




}//end..
 ?>
