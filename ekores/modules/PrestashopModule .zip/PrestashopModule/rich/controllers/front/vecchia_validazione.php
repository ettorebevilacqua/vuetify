<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
class RichValidationModuleFrontController extends ModuleFrontController
{
    /**
    * @see FrontController::postProcess()
    */
    public function postProcess()
    {
        $cart = $this->context->cart;
        $status=2;
        session_start();
        if(!empty($_SESSION["amount"]))
        $amount=$_SESSION["amount"];
        else
          exit;



        //IDENTIFICO IL TIPO DI CLIENTE
        include "classes/client.php";
        $id = (int)$this->context->cookie->id_customer;
        $c=new Client($id);
        


          if($c->clienteMaggioreDiTre() && !$c->isRE())
          {

            // SE NON È RE
            //MA È FIGLIO DIRETTO DEL RE CIOÈ SE PRINCIPE
            //ID_PADRE
              $id_padre=$c->calcolaIdPadre();
              $id_figlio=$id;
              $array=array();
              foreach($cart->getProducts() as $elem)
              {
                $price=$elem['total_wt'];
                $id_product=$elem['id_product'];
                $volume_ritenuta=$this->getVolumeRitenuta($id_product);
                $percentuale_volume=($price*$volume_ritenuta[0])/100;
                $provvigione=($percentuale_volume*$volume_ritenuta[1])/100;
                $first_last_name=$this->getNomeCognomeByIdCustomer($id_figlio);
                $name_product=$this->getNomeProdottoByIdProduct($id_product);
                $name_padre=$this->getNomeCognomeByIdCustomer($id_padre);
                $this->salvaAcquisto($id_padre,$name_padre,$id_figlio,$first_last_name,
                $id_product,$name_product,$price,$provvigione);
              }//end FOREACH
              $this->module->validateOrder((int)$cart->id, _PS_OS_PAYMENT_, $amount, $this->module->displayName,
               "Customer redirected", array('transaction_id' => $this->context->cookie->pcid), false, false,
                $this->context->customer->secure_key,$this->context->shop);
                $this->context->smarty->assign(array('response1'=>"<h1>SUCCESS!</h1>"));
                $this->setTemplate('validation.tpl');
          }//end IF

          // SE NON È IL RE
         //  SE NON È FIGLIO DIRETTO DEL PADRE
  if(!$c->isFiglioDelRe() && !$c->isRE() && $c->sonoTraPrimiDueNipoti())
        {

            $id_figlio=$id;

            foreach($cart->getProducts() as $elem)
            {
              $price=$elem['total_wt'];
              $id_product=$elem['id_product'];
              $volume_ritenuta=$this->getVolumeRitenuta($id_product);
              $percentuale_volume=($price*$volume_ritenuta[0])/100;
              $provvigione=($percentuale_volume*$volume_ritenuta[1])/100;
              $first_last_name=$this->getNomeCognomeByIdCustomer($id_figlio);
              $name_product=$this->getNomeProdottoByIdProduct($id_product);
              $name_padre=$this->getNomeCognomeByIdCustomer($c->getRe());

            //  $this->salvaAcquisto($c->getRe(),$name_padre,$id_figlio,$first_last_name,$id_product,$name_product,$price,$provvigione);
              $id_padre=$c->calcolaIdPadre();
              $padre=$this->getNomeCognomeByIdCustomer($id_padre);
              $this->salvaAcquisto($id_padre,$padre,$id_figlio,$first_last_name,$id_product,$name_product,$price,$provvigione);
              $p=new Client($id_padre);
              $id_nonno=$p->calcolaIdPadre();
              $nonno=$this->getNomeCognomeByIdCustomer($id_nonno);
              $this->salvaAcquisto($id_nonno,$nonno,$id_figlio,$first_last_name,$id_product,$name_product,$price,$provvigione);

            }//end FOREACH

            $this->module->validateOrder((int)$cart->id, _PS_OS_PAYMENT_, $amount, $this->module->displayName,
             "Customer redirected", array('transaction_id' => $this->context->cookie->pcid), false, false,
              $this->context->customer->secure_key,$this->context->shop);
              $this->context->smarty->assign(array('response1'=>"<h1>SUCCESS!</h1>"));
              $this->setTemplate('validation.tpl');

        }//end IF



      }//end function




/**
 * Trovare nome e cognome cliente dato il suo id
 *
 * @param  [int] $id [id_customer]
 * @return [Array of String]     ["firstname","lastname"]
 */
  private function getNomeCognomeByIdCustomer($id)
  {
      $sql="SELECT firstname,lastname FROM "._DB_PREFIX_."customer WHERE id_customer=".$id;
      $results=Db::getInstance()->query($sql);
      while ($row=Db::getInstance()->nextRow($results))
       {
              if($row)
                return ($row['firstname']." ".$row['lastname']);
        }
       return null;
  }

  /**
   * Dato l'id del prodotto cerco il suo nome nel DB
   * @param  [Int] $id [id_product]
   * @return [String]     [name]
   */
  private function getNomeProdottoByIdProduct($id)
  {
    global $cookie;
    $id_lang = $cookie->id_lang;
    $productObj = new Product();
    $products = $productObj -> getProducts($id_lang, 0, 0, 'id_product', 'ASC' );
    foreach($products as $elem)
    {
      if($elem['id_product']==$id)
      return $elem['name'];
    }
  }





  /**
   * Dato l'id del prodotto seleziono il volume e la ritenuta
   * @param  [int] $id [id_product]
   * @return [Array of Float]     [0=>volume,1=>ritenuta]
   */
  private function getVolumeRitenuta($id)
  {
    $sql="SELECT volume,ritenuta FROM "._DB_PREFIX_."relazione_volume_provvigione WHERE id_product=".$id;
    $results = Db::getInstance()->query($sql);
       while ($row=Db::getInstance()->nextRow($results))
        {
        if($row)
            return array($row['volume'],$row['ritenuta']);
        }
        return null;
  }






    /**
     * Salva l'acquisto con invito
     * @param  [int] $padre         [id_padre]
     * @param  [String] $name_padre    [nome del padre]
     * @param  [int] $figlio        [id figlio]
     * @param  [String] $nome_cognome  [nome e cognome del figlio]
     * @param  [int] $prodotto      [id_product]
     * @param  [String] $nome_prodotto [Nome Prodotto]
     * @param  [Float] $total         [Prezzo totale con  tasse e tutto]
     * @param  [float] $provvigione   [provvigione/guadagno del padre]
     * @return [null]                [/]
     */
    private function salvaAcquisto($padre,$name_padre,$figlio,$nome_cognome,
    $prodotto,$nome_prodotto,$total,$provvigione)
    {
      $sql="INSERT INTO ps_acquisti_inviti (id,id_padre,nome_padre,id_figlio,nome_cognome,id_prodotto,nome_prodotto,total_price,provvigione)
       VALUES (null,".$padre.",'".$name_padre."',".$figlio.",'".$nome_cognome."',".$prodotto.",'".$nome_prodotto."',".$total.",".$provvigione.")";

       $result=Db::getInstance()->query($sql);
    }


}//..end
 ?>
