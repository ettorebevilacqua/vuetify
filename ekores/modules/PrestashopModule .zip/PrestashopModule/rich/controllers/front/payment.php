<?php
/**ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);**/
class RichPaymentModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_column_left = false;

    /**
    * @see FrontController::initContent()
    */
    public function initContent()
    {
        parent::initContent();
        $cart = $this->context->cart;
        session_start();
        $_SESSION["amount"] = $cart->getOrderTotal(true, Cart::BOTH);
        $validation=$this->context->link->getModuleLink('rich','validation');
        $this->context->smarty->assign(array(
          //  'nbProducts' => $cart->nbProducts(),
          //  'cust_currency' => $cart->id_currency,
          //  'currencies' => $this->module->getCurrency((int)$cart->id_currency),
          '_link'=>$validation,
            'total' => $cart->getOrderTotal(true, Cart::BOTH)
          //  'this_path' => $this->module->getPathUri(),
          //  'this_path_bw' => $this->module->getPathUri(),
        //    'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/'
        ));

        $this->setTemplate('payment_execution.tpl');
    }

}//..end
 ?>
