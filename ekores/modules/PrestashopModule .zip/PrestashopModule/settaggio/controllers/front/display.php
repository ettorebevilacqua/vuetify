<?php

class settaggiodisplayModuleFrontController extends ModuleFrontController
{

  public function initContent()
  {
    parent::initContent();
    $id = (int)$this->context->cookie->id_customer;
    
  if($id==0)
  {
    Tools::redirect('index.php?controller='.(($this->authRedirection !== false) ?
    url_encode($this->authRedirection) : 'my-account'));
  }
    else
    {
      $sql = 'SELECT * FROM '._DB_PREFIX_.'customer WHERE id_customer ='.$id.';';
      if ($row = Db::getInstance()->getRow($sql))
      {
      $promotion_code=$row['firstname'][0].$row['id_customer'].$row['lastname'][0].$row['id_shop'];
      $this->context->smarty->assign('promotion_code',$promotion_code);
      $this->setTemplate('display.tpl');
    }
    else
    {
      $this->context->smarty->assign('promotion_code',"ERROR");
      $this->setTemplate('display.tpl');
    }

   }

  }



}//..end

?>
