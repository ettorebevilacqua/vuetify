<?php
require __DIR__  .'/PayPal-PHP-SDK/autoload.php';

$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        'AW792M-PnzZXH3c_Wd2g66RhCMfarEKFgvkw-4AuknRqNiI81x6UWAwMPycydblZgxhmB6ufMwBflxGd',     // ClientID
        'ELjbMePLBCwgI6TdvIYSQkcCPWSmeEvTzlH_fThxqkfM61gzBF0ZVgroC0Sr9MOkBcmiPv7h4W-YehwE'      // ClientSecret
    )
);
 ?>
