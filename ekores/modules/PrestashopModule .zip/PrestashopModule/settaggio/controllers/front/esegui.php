<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


class settaggioeseguiModuleFrontController extends ModuleFrontController
{

  public function initContent()
  {
    parent::initContent();
    $amount=Tools::getValue('amount');
    $email=Tools::getValue('email');
  /*  require __DIR__ .('/config.php');
    $payouts = new \PayPal\Api\Payout();
    $senderBatchHeader = new \PayPal\Api\PayoutSenderBatchHeader();
    // ### NOTE:
    // You can prevent duplicate batches from being processed. If you specify a `sender_batch_id` that was used in the last 30 days, the batch will not be processed. For items, you can specify a `sender_item_id`. If the value for the `sender_item_id` is a duplicate of a payout item that was processed in the last 30 days, the item will not be processed.
    // #### Batch Header Instance
    $senderBatchHeader->setSenderBatchId(uniqid())
        ->setEmailSubject("You have a Payout!");
    // #### Sender Item
    // Please note that if you are using single payout with sync mode, you can only pass one Item in the request
    $senderItem = new \PayPal\Api\PayoutItem();
    $senderItem->setRecipientType('Email')
        ->setNote('Thanks for your patronage!')
        ->setReceiver($email)
        ->setSenderItemId("1")
        ->setAmount(new \PayPal\Api\Currency('{
                            "value":'.$amount.',
                            "currency":"EUR"
                        }'));
                        $payouts->setSenderBatchHeader($senderBatchHeader)
                            ->addItem($senderItem);
                        // For Sample Purposes Only.
                        $request = clone $payouts;
                        // ### Create Payout
                        try {
                            $output = $payouts->createSynchronous($apiContext);
                        } catch (Exception $ex) {
                            // NOTE: PLEASE DO NOT USE RESULTPRINTER CLASS IN YOUR ORIGINAL CODE. FOR SAMPLE ONLY
                        // 	ResultPrinter::printError("Created Single Synchronous Payout", "Payout", null, $request, $ex);
                        echo "exit";
                        //    exit(1);
                        }
                        if($output->getBatchHeader()->getBatchStatus()=="SUCCESS")
                        {**/

                          $id_padre=(int)$this->context->cookie->id_customer;
                          $this->eliminaProvvigioneById($id_padre);
                      //  }
    $this->salvaScontrino(number_format((float)$amount,2,'.',''),$id_padre);
    $this->context->smarty->assign(array('status'=>"SUCCESS"));

    //$this->context->smarty->assign(array('status'=>$output->getBatchHeader()->getBatchStatus()));
    $this->setTemplate('esegui.tpl');
  }


  /**
   * Elimina provvigione dal DB
   * @param  [int] $id_padre [ID del padre]
   * @return [null]           [/]
   */
  private function eliminaProvvigioneById($id_padre)
  {
    $sql = 'DELETE FROM '._DB_PREFIX_.'acquisti_inviti WHERE id_padre='.$id_padre;
    $results = Db::getInstance()->query($sql);
  }


  private function salvaScontrino($amount,$id_customer){
    require('storiaBuonoTable.php');
    $b=new StoriaBuonoTable(_DB_PREFIX_."storia_buono");
    date_default_timezone_set('UTC');
    $date = date('Y-m-d H:i:s');
    $id_customer=(int)$this->context->cookie->id_customer;
    $b->newRow($amount,$id_customer,$date);
  }


}//..end
?>
