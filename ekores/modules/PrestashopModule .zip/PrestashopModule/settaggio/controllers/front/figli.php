<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("utils/utils_figli.php");

class settaggiofigliModuleFrontController extends ModuleFrontController
{

  public function initContent()
  {
    parent::initContent();

          $id = (int)$this->context->cookie->id_customer;
          $provvigione=getProvvigioni($id);
          $array_guadagni=getGuadagni($id);

          $paypal=$this->context->link->getModuleLink('settaggio','trasferisci');
          $buono=$this->context->link->getModuleLink('buono','creabuono');
          require("TableAbstract.php");require('rimborsoTable.php');
          $table=new rimborsoTable(_DB_PREFIX_.'rimborso');

          //POSSIBILI ACQUIRENTI DA CUI POSSO GUADAGNARE
          $acquirenti=getPotenzialiClienti($id);
          //TABELLA ACQUIRENTI
          $table_acquirenti=$this->createTableAcquirenti($acquirenti);

          $this->context->smarty->assign(array('table'=>$array_guadagni,'provvigione'=>$provvigione,
          'paypal'=>$paypal,'stato'=>$table->getStato(),'buono'=>$buono,
          "trasferimenti"=>createTableTrasferimenti($id),"acquirenti"=>$table_acquirenti));
          $this->setTemplate('figli.tpl');
  }



  /**
   * Crea tabella "POSSIBILI ACQUIRENTI"
   * @param  [Array of Array of Int] $acquirenti [[0]=>Figli,[1]=>Nipoti]
   * @return [String]             [html table]
   */
  private function createTableAcquirenti($acquirenti)
  {
    $figli=(array_key_exists(0,$acquirenti)?$acquirenti[0]:null);
    $nipoti=(array_key_exists(1,$acquirenti)?$acquirenti[1]:null);

    $html=$this->getHead();

    $html=$html.$this->createBodyTable($figli);
    $html=$html.$this->createBodyTable($nipoti)."</table>";
    return $html;

  }


  /**
   * Crea l'heading della tabella per i possibili acquirenti
   * @return [String] [HTML]
   */
  private function getHead()
  {
      return "<h1>POSSIBILI ACQUIRENTI</h1></br></br>
      <table class='table table-bordered table-responsive'><tr>
      <th>ID</th><th>Nome </th><th>Cognome</th><th>Email</th>
      <th>Data Iscrizione</th></tr>";
  }

  /**
   * Crea il corpo della tabella "POSSIBILI ACQUIRENTI"
   * @param  [type] $acquirenti [description]
   * @return [type]             [description]
   */
  private function createBodyTable($acquirenti)
  {
    $html="";
    foreach($acquirenti as $cliente)
    {
        $info=getInfoOfClient($cliente);
        $html.="<tr>";
          foreach($info as $elem)
            $html.="<td>".$elem."</td>";
    }
      $html.="</tr>";
    return $html;
  }


}//end..


 ?>
