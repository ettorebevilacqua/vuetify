<?php
/**
 * Aggiunge l'attributo INVITO
 * alla tabella 'PS_CUSTOMER'
 * Se l'attributo esiste già non lo crea
 */

function AddAttributoInvito()
{
  try{      //AGGIUNGO ALLA TABELLA ps_customer il PROMOTION CODE
    $sql='ALTER TABLE '._DB_PREFIX_.'customer ADD COLUMN promotion_code VARCHAR(250)';
  Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
} catch (Exception $e) {
  //ESISTE GIÀ NON SUCCEDE NIENTE
  }
}

/**
 * Crea Tabella PS_RICCARDO
 * Se esiste già la elimina e la ricrea
 */
function tableRiccardo()
{
  require('riccardoTable.php');
  $table=new riccardoTable(_DB_PREFIX_.'relazione_volume_provvigione');
  if($table->checkExist())
     {$table->dropTable();
       $table->createTableRiccardo();
     }
     else
  $table->createTableRiccardo();
}

/**
 * Verifica se la tabella 'ps_custom' esista e sia inizializzata la tabella
 * Se esiste significa che prestashop è già personalizzato
 * Se non esiste allora la crea e la iniazilizza
 * Dopodiche aggiunge a prestashop le pagine già personalizzate
 * Spostandole dalla cartella FILES alle varie cartelle di prestashop
 */
function addCustomPage()
{
require('customTable.php');
$customTable=new customTable(_DB_PREFIX_.'custom');
$dir=$customTable->getDir();
if(!$customTable->checkExist()){
  $customTable->createTable();
  $customTable->inizializza();
  $path=dirname(__FILE__);
  $customTable->sposta($dir.'themes/default-bootstrap/authentication.tpl',$path.'/files.php/authentication.tpl');
  $customTable->sposta($dir.'controllers/front/AuthController.php',$path.'/files.php/AuthController.php');
  $customTable->sposta($dir.'classes/Customer.php',$path.'/files.php/Customer.php');
  $customTable->sposta($dir.'admin1/themes/default/template/controllers/customers/helpers/view/view.tpl',
  $path.'/files.php/view.tpl');
  $customTable->sposta($dir.'themes/default-bootstrap/identity.tpl',$path.'/files.php/identity.tpl');
  $customTable->sposta($dir.'controllers/admin/AdminCustomersController.php',
  $path.'/files.php/AdminCustomersController.php');
  $customTable->sposta($dir.'themes/default-bootstrap/my-account.tpl',$path.'/files.php/my-account.tpl');
  }
}



/**
 * Installiamo la tabella sul Base Dati
 * se esiste la elimina
 * @return [null]
 */
function configuraRimborsoTable()
{
require('rimborsoTable.php');
$table=new rimborsoTable(_DB_PREFIX_.'rimborso');
if($table->checkExist()){
  $table->dropTable();
  $table->createTable();
}
else {
$table->createTable();
}
}



//end file..
 ?>
