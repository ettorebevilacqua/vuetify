<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



class customTable extends TableAbstract
{
     /**
      * Crea la tabella 'PS_CUSTOMER'
      * @return null
      */
   public function createTable()
   {
     $sql='CREATE TABLE '.$this->name.' ( id int NOT NULL AUTO_INCREMENT, installato boolean ,primary key (id));';
   try {
              $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
       } catch (Exception $e)
       {   //ESISTE GIÀ LA TABELLA
       }
   }


   /**
    * Inizializza la tabella 'ps_customer'
    * @return [BOOLEAN] [TRUE se l'opeazione è conclusa correttamente, FALSE altrimenti]
    */
   public function inizializza()
   {
     $sql='INSERT INTO '.$this->name.' (installato) VALUES (TRUE)';
     try {
              Db::getInstance(_PS_USE_SQL_SLAVE_)->Execute($sql);
          } catch (Exception $e)
          {
            return false;
          }
     return true;
   }

   /**
    * Sposta un file in un altra cartella
    * @param  [string] $vecchio [PATH del vecchio indirizzo (con il nome del file)]
    * @param  [type] $nuovo   [PATH del nuovo indirizzo (con il nome del file)]
    * @return null
    */
   public function sposta($vecchio,$nuovo)
   {
     unlink($vecchio);//elimino file vecchio
     $dir=dirname($vecchio).'/';//trovo nome directory destinazione
     $file=basename($nuovo);//trovo nome file
     $dir=$dir.$file;
     copy($nuovo,$dir);
   }

   /**
    * Calcola l'indirizzo della Directory in cui sta
    * @return [string] [PATH alla Directory]
    */
   public function getDir()
   {
     $dir=getcwd();
     $array=explode('/',$dir);
     $path=null;$i=0;
     foreach($array as $elem)
     {
     if($elem!="modules" &&
      $elem!="settaggio" &&
      $elem!="admin1" &&
      $elem!="classes" &&
      $elem!="installation")
       $path=$path.$elem."/";
     }
     $dir=$path;
     return $dir;
    }

 }//end class..


 ?>
