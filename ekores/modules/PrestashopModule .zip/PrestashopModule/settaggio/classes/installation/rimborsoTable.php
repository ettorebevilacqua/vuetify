<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);




class rimborsoTable extends TableAbstract
{
  /**
   * Crea la tabella 'PS_rimborso'
   * @return null
   */
 public function createTable()
 {
  $sql='CREATE TABLE '.$this->name.' ( id int NOT NULL AUTO_INCREMENT, paypal boolean ,buono boolean,primary key (id));';
 try {
          $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
     } catch (Exception $e)
          {   //ESISTE GIÀ LA TABELLA
          }
  }

  /**
   * Imposta la modalità di risarcimento
   * @param [string] $option ["paypal","buono"]
   */
  public function setStato($paypal,$buono)
  {
    $this->deleteRows();//ELIMINO TUTTE LE RIGHE

    $sql="INSERT INTO $this->name (paypal,buono) VALUES ($paypal,$buono)";
    try {
          $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        } catch (Exception $e)
        {//ERRORE
        }
  }

  /**
   * Ritorna lo stato
   * @return [type] [description]
   */
  public function getStato()
  {
    $sql="SELECT * FROM $this->name ";
    $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
    while ($row=Db::getInstance()->nextRow($results))
    {
      if($row)
      {
        $array=array("paypal"=>$row["paypal"],"buono"=>$row["buono"]);
      return $array;
      }
    }
    return null;

  }



  /**
   * Elimina tutte le righe dalla tabella
   * @return [null]
   */
  private function deleteRows()
  {
    $sql="DELETE FROM $this->name WHERE 1";
    try {
            $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        } catch (Exception $e)
                { //ERRORE
                }
  }



}//..end

 ?>
