<?php



class RiccardoTable extends TableAbstract
{
 /**
  * [Creo la tabella PS_RICCARDO]
  * @return null
  */
  public function createTableRiccardo()
  {
    $sql = 'CREATE TABLE  '.$this->name.' ( id_product int, volume float, ritenuta float);';
    try {
            $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        } catch (Exception $e) {
//ESISTE GIÀ LA TABELLA
                               }
  }


  /**
   * Resituisce il volume di un prodotto
   * @param  [int] $id_product [id prodotto]
   * @return [float]             [percentuale volume]
   */
  public function getVolume($id_product)
  {
    $sql='SELECT volume FROM '.$this->name.' WHERE id_product=\''.$id_product.'\'';
    $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
    while ($row=Db::getInstance()->nextRow($results))
    {
      if($row)
      return $row['volume'];
    }
    return null;
  }



    /**
     * [Prende la ritenuta di un prodotto]
     * @param  [int] $id_product [Id prodotto]
     * @return [float]             [Ritenuta fiscale]
     */
    public function getRitenuta($id_product)
    {
      $sql='SELECT ritenuta FROM '.$this->name.' WHERE id_product=\''.$id_product.'\'';
      $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
      while ($row=Db::getInstance()->nextRow($results))
      {
        if($row)
        return $row['ritenuta'];
      }
      return null;
    }



       /**
        * Imposta la percentuale volume e la salva sul DB anche se vuota
        * @param [int] $id_product [id prodotto]
        * @param [float] $volume     [percentuale volume]
        */
      public function setVolume($id_product,$volume)
      {
      if($volume=="")   $volume='null';

      if($this->checkIfRowExist($id_product))
      {
        //AGGIORNO SOLO IL VALORE DELLA RIGA
        $sql='UPDATE '.$this->name.' SET volume='.$volume.' WHERE id_product='.$id_product;
        Db::getInstance(_PS_USE_SQL_SLAVE_)->Execute($sql);
      }
      else{
        //INSERISCO UNA NUOVA RIGA
        $sql='INSERT INTO '.$this->name.' (id_product, volume , ritenuta) VALUES ('.$id_product.','.$volume.',null)';
        Db::getInstance(_PS_USE_SQL_SLAVE_)->Execute($sql);
          }
      }

      /**
       * Imposto ritenuta e salvo sul DB
       * @param [int] $id_product [id prodotto]
       * @param [float] $ritenuta   [percentuale ritenuta]
       */
      public function setRitenuta($id_product,$ritenuta)
      {
        if($ritenuta=="") $ritenuta='null';

      if($this->checkIfRowExist($id_product))
      {
        //AGGIORNO SOLO IL VALORE DELLA RIGA
        $sql='UPDATE '.$this->name.' SET ritenuta='.$ritenuta.' WHERE id_product='.$id_product;
        try {
                Db::getInstance(_PS_USE_SQL_SLAVE_)->Execute($sql);
            } catch (Exception $e) {  //ERRORE
               }
      }
      else{
        //INSERISCO UNA NUOVA RIGA
        $sql='INSERT INTO '.$this->name.' (id_product, volume , ritenuta) VALUES ('.$id_product.',null,'.$ritenuta.')';
        try {
                Db::getInstance(_PS_USE_SQL_SLAVE_)->Execute($sql);
            } catch (Exception $e) { //ERRORE
             }
          }
        }



       /**
        * RITORNA TRUE SE ESISTE ALMENO UNA RIGA CON QUELL'ID_PRODUCT
        * @param  [id] $id_product [id prodotto]
        * @return [boolean]             [TRUE se ha trovato almeno una riga, FALSE altrimenti]
        */
      private function checkIfRowExist($id_product)
      {
        $sql='SELECT * FROM '.$this->name.' WHERE id_product=\''.$id_product.'\'';
        $results=Db::getInstance(_PS_USE_SQL_SLAVE_)->query($sql);
        while ($row=Db::getInstance()->nextRow($results))
        {
          if($row)
           return true;
          else
            return false;
        }
      }



}//end..

 ?>
